#include "circuit.h"

int Circuit::createABSMIN9X12YModule(const string &input1, const string &input2, const string &output)
{
  // after you have implemented this function,
  // change 'return -1' to 'return 0'
  return -1;
}

